import React,{useState,useEffect} from 'react';
import Images from './Images';
import Heading from './Heading';
import samsung from './samsung.jpg'


const imgList={
    "samsung":samsung
}
const Tv = ()=>{
    const [tdata,settdata] = useState()
    useEffect(()=>{
        fetch(`http://localhost:4000/product/tv`)
        .then(response => response.json())
        .then(json => settdata(json))
    },[])
    const createTvList = (tdata) =>{
        return tdata.map(({name,image},index)=>{
        let valsrc=image;
        for(var x in imgList){
            if(x === image){
                valsrc=imgList[x];
            }
        }
        return(
            <li key={index}>
               <Images src={valsrc} alt="Tv" style={{width:"200px",height:"200px"}}/>
                <Heading heading={name}/>
            </li>
        )})
    }


    return(
        <div>
            <Heading heading="Tv Products to Check Out"/>
            <ul style={{listStyle:"none", textAlign:"left", paddingLeft:"10px", paddingTop:"5px"}}>
               {tdata && createTvList(tdata)}
            </ul>
        </div>
    )
}

export default Tv;