import React,{useState,useEffect} from 'react';
import {useParams} from 'react-router-dom'
import UList from './UList'

const Profile = ()=>{
    const [data,setData] = useState()
    const params=useParams();
    const uname=params.uname;

    useEffect(() =>{
        fetch(`http://localhost:4000/user/${uname}`)
       .then(response => response.json())
       .then(json => setData(json))
    },[]);
    
    return(
        <UList data={data}/>
    )
}

export default Profile