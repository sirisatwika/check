import React from "react";

const AboutUs =() =>{
    return (
        <div data-testid = "about-msg">
    <h1>AboutUs</h1>
    </div>
    )
}
export default AboutUs;
