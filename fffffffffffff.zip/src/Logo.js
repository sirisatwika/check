import React from 'react';
import logo from './logo.png';


const Logo = () => {
    return (
        
    
    <img src={logo} className="App-logo" alt="logo" />
    
    )
}

export default Logo;