import React from "react";

const Color =() =>{
    return <h1>Color</h1>
}
export default Color;