import React from "react";

const Size =() =>{
    return <h1>Size</h1>
}
export default Size;