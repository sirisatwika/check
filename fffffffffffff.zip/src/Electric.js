import React,{useState,useEffect} from 'react';
import Images from './Images';
import Heading from './Heading';
import laptop from './laptop.jpg'


const imgList={
    "laptop":laptop
}
const Electric = ()=>{
    const [edata,setedata] = useState()
    useEffect(()=>{
        fetch(`http://localhost:4000/product/electric`)
        .then(response => response.json())
        .then(json => setedata(json))
    },[])
    const createElectricList = (edata) =>{
        return edata.map(({name,image},index)=>{
        let valsrc=image;
        for(var x in imgList){
            if(x === image){
                valsrc=imgList[x];
            }
        }
        return(
            <li key={index}>
               <Images src={valsrc} alt="Electric" style={{width:"200px",height:"200px"}}/>
                <Heading heading={name}/>
            </li>
        )})
    }


    return(
        <div>
            <Heading heading="Electric Products to Check Out"/>
            <ul style={{listStyle:"none", textAlign:"left", paddingLeft:"10px", paddingTop:"5px"}}>
               {edata && createElectricList(edata)}
            </ul>
        </div>
    )
}

export default Electric;