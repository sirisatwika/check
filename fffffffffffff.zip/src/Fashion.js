import React,{useState,useEffect} from 'react';
import blackdress from './blackdress.jpg'
import handbag from './handbag.jpg'
import kurti from './kurti.jpg'
import Images from './Images';
import Heading from './Heading';


const imgList={
    "blackdress":blackdress,
    "kurti":kurti,
    "handbag":handbag
}
const Fashion = ()=>{
    const [fdata,setfData] = useState()
    useEffect(()=>{
        fetch(`http://localhost:4000/product/fashion`)
        .then(response => response.json())
        .then(json => setfData(json))
    },[])
    const createFashionList = (fdata) =>{
        return fdata.map(({name,image},index)=>{
        let valsrc=image;
        for(var x in imgList){
            if(x === image){
                valsrc=imgList[x];
            }
        }
        return(
            <li key={index}>
               <Images src={valsrc} alt="fashion" style={{width:"200px",height:"200px"}}/>
                <Heading heading={name}/>
            </li>
        )})
    }


    return(
        <div>
            <Heading heading="Fashion Products to Check Out"/>
            <ul style={{listStyle:"none", textAlign:"left", paddingLeft:"10px", paddingTop:"5px"}}>
               {fdata && createFashionList(fdata)}
            </ul>
        </div>
    )
}

export default Fashion;