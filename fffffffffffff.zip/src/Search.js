import React from 'react';
import './App.css';

const Search = () =>{

    return(
            <div class = "App-search">
            <input type="text" placeholder="Search.." />
            </div>
    )
}

export default Search;