import React,{useState,useEffect} from 'react';
import Images from './Images';
import Heading from './Heading';
import washingmachine from './washingmachine.jpg'


const imgList={
    "washingmachine":washingmachine
}
const HomeApp = ()=>{
    const [hdata,sethdata] = useState()
    useEffect(()=>{
        fetch(`http://localhost:4000/product/homeapp`)
        .then(response => response.json())
        .then(json => sethdata(json))
    },[])
    const createHomeAppList = (hdata) =>{
        return hdata.map(({name,image},index)=>{
        let valsrc=image;
        for(var x in imgList){
            if(x === image){
                valsrc=imgList[x];
            }
        }
        return(
            <li key={index}>
               <Images src={valsrc} alt="HomeApp" style={{width:"200px",height:"200px"}}/>
                <Heading heading={name}/>
            </li>
        )})
    }


    return(
        <div>
            <Heading heading="HomeApp Products to Check Out"/>
            <ul style={{listStyle:"none", textAlign:"left", paddingLeft:"10px", paddingTop:"5px"}}>
               {hdata && createHomeAppList(hdata)}
            </ul>
        </div>
    )
}

export default HomeApp;