import React from "react";
import Navigation from "./Navigation";
import Body from "./Body";

const Home =() =>{
    return (
        <>
       
        <Body />
        </>
    )
}
export default Home;