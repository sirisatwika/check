import React from 'react';

const Logout = () =>{
    return (
         <button>Signout</button>

    )
}

export default Logout;